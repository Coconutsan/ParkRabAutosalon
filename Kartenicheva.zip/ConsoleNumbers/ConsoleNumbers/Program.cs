﻿using System;

namespace ConsoleNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int FirstNumber, SecondNumber;
            Console.WriteLine("Hello!");
            Console.WriteLine("Please enter the first number:");
            FirstNumber = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the second number:");
            SecondNumber = int.Parse(Console.ReadLine());
            int Step = 0;
            int Summa = 0;
            while (Step < 1001)
            {
                Console.WriteLine(Summa = FirstNumber + SecondNumber + Summa);
                Step = Step + 1;
            }
            Console.WriteLine(Step);
            Console.WriteLine(Summa);
            Console.ReadKey();

        }
    }
}
