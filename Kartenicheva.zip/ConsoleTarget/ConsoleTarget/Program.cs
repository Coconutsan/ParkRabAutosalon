﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTarget
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tap of data X=");
            Random rand = new Random();
            int FirstNumber = rand.Next(0, 4);
            Console.WriteLine(FirstNumber);
            Console.WriteLine("Tap of data Y=");
            Random rand2 = new Random();
            int SecondNumber = rand2.Next(0, 4);
            Console.WriteLine(SecondNumber);
            int Try = 0;
            int Score = 0;
            while (Try == 3)
                {
                    double Total = FirstNumber * FirstNumber + SecondNumber * SecondNumber;

                    if (Total <= 1) Score = 3;
                    
                    else if ((Total > 1) && (Total <= 2)) Score = 3;
                    else if ((Total > 2) && (Total <= 3)) Score = 2;
                    else if ((Total > 3) && (Total <= 4)) Score = 1;
                    else Score = 0;
                Score = Score + Score;    
                Try = Try + 1;
                
                }
                    Console.WriteLine("Total score of Archer:");
                    Console.WriteLine(Score);
                    Console.ReadKey();
                
            
        }
    }
}
