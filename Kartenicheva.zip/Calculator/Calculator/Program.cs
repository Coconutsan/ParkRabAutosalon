﻿using System;

namespace Calculator
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Здравствуйте");
			
			
			double a, b,total;

			char oper;

			Console.WriteLine("Введите первое число:");
			a = Convert.ToDouble(Console.ReadLine());

			Console.WriteLine("Введите действие:");
			oper = Convert.ToChar(Console.ReadLine());

			Console.WriteLine("Введите второе число:");
			b = Convert.ToDouble(Console.ReadLine());

			if (oper == '=')
			{
				total = a + b;
				Console.WriteLine(a + "+" + b + "=" + total + ".");
			}
			else if (oper == '-')
			{
				total = a - b;
				Console.WriteLine(a + "-" + b + "=" + total + ".");
			}
			else if (oper == '*')
			{
				total = a * b;
				Console.WriteLine(a + "*" + b + "=" + total + ".");
			}
			else if (oper == '/')
			{
				total = a / b;
				Console.WriteLine(a + "/" + b + "=" + total + ".");
			}
			else
			{
				Console.WriteLine("Неизвестное действие.");
			}
			Console.ReadKey();
		}
	}
}
