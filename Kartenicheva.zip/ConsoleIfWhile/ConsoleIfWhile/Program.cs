﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleIfWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, total, second;
            int numb, zero;
            char oper;
            Console.WriteLine("Введиде первое число:");
            a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите символ:");
            oper = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Введите второе число:");
            b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("На с колько данное выражение будет умножено раз?");
            numb = Convert.ToInt32(Console.ReadLine());
            zero = 0;
            while (zero == numb)
            {
                if (oper == '+')
                {
                    second = a + b;
                    total = second * numb;
                    Console.WriteLine(total);
                }

                else if (oper == '-')
                {
                    second = a - b;
                    total = second * numb;
                    Console.WriteLine(total);
                }
                else if (oper == '*')
                {
                    second = a * b;
                    total = second * numb;
                    Console.WriteLine(total);
                }
                else if (oper == '/')
                {
                    second = a / b;
                    total = second * numb;
                    Console.WriteLine(total);
                }
                else
                {
                    Console.WriteLine("Неизвестный символ.");
                }
            }
            zero = zero + 1;
            /*}
             while (step == 1000)
                {
                    second = a + b;
                    total = second* numb;
            Console.WriteLine(total);
                    step++;
                }
                */

        }
    }
}
