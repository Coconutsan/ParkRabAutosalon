﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApple
{
    class Program
    {
        static void Main(string[] args)
        {
            double FirstApple, SecondApple, Summ;
            Console.WriteLine("Введите первое число:");
            FirstApple =Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите второе число:");
            SecondApple = Convert.ToDouble(Console.ReadLine());
            Summ = FirstApple + SecondApple;
            Console.WriteLine(Summ);
            Console.ReadKey();
        }
    }
}
