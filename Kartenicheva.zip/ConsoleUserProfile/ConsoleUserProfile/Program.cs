﻿using System;

namespace ConsoleUserProfile
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Здравствуйте!Пожалуйста, введите свои данные.");
            Console.WriteLine("Имя: ");
            string Name = (Console.ReadLine());
            Console.WriteLine("Фамилия: ");
            string Surname = (Console.ReadLine());
            Console.WriteLine("Отчество: ");
            string LName = (Console.ReadLine());
            Console.WriteLine("Возраст: ");
            float Years = float.Parse(Console.ReadLine());
            Console.WriteLine("Пол: М или Ж ");
            string Gender = (Console.ReadLine());
            Console.WriteLine("Место учёбы: ");
            string PlaceOfStudy = (Console.ReadLine());
            Console.WriteLine(" Группа: ");
            string Group = (Console.ReadLine());



            Console.WriteLine(" \n**********************************\n* *\n* АНКЕТА ПОЛЬЗОВАТЕЛЯ *" + "\n**********************************\nФИО: " + Surname + " " + Name + " " + LName + "\nВозраст: " + Years +
            "\nПол: " + Gender + "\nМесто учёбы: " + PlaceOfStudy + "\nГруппа: " + Group + "\n* *\n**********************************");
            Console.ReadKey();
        }
    }
}
